import os
import logging

from pyramid.config import Configurator
from pyramid.events import NewRequest
from pyramid.events import subscriber
from pyramid.events import ApplicationCreated
from pyramid.httpexceptions import HTTPFound
from pyramid.session import UnencryptedCookieSessionFactoryConfig
from pyramid.authentication import AuthTktAuthenticationPolicy
from pyramid.authorization import ACLAuthorizationPolicy
from pyramid.view import view_config
from pyramid.security import remember, forget


from wsgiref.simple_server import make_server


logging.basicConfig()
log = logging.getLogger(__file__)

here = os.path.dirname(os.path.abspath(__file__))

USERS = {
    'admin': 'password'
}


@view_config(route_name='main', renderer='main.mako')
def main_view(request):
    return {}


@view_config(route_name='login', renderer='login.mako')
def login_view(request):
    login = request.params.get('login')
    password = request.params.get('password')
    if request.method == 'POST':
        if login and USERS.get(login) == password:
            headers = remember(request, login)
            return HTTPFound('/', headers=headers)
    return {}


@view_config(route_name='logout')
def logout(request):
    headers = forget(request)
    return HTTPFound(location='/', headers=headers)


if __name__ == '__main__':
    # configuration settings
    settings = {}
    settings['mako.directories'] = here
    authn_policy = AuthTktAuthenticationPolicy('sosecret', hashalg='sha512')
    authz_policy = ACLAuthorizationPolicy()
    config = Configurator(settings=settings)
    config.include('pyramid_mako')
    config.add_static_view('static', os.path.join(here, 'static'))
    config.set_authentication_policy(authn_policy)
    config.set_authorization_policy(authz_policy)
    config.add_route('main', '/')
    config.add_route('login', '/login')
    config.add_route('logout', '/logout')
    config.scan()
    app = config.make_wsgi_app()
    server = make_server('0.0.0.0', 8080, app)
    server.serve_forever()
